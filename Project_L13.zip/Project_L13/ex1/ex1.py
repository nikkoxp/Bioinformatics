import math

# ==========================================
# 1. SETUP & DATA
# ==========================================

# Training Sequences from the prompt
S1_ISLAND = "ATCGATTCGATATCATACACGTAT"          # Model (+)
S2_NON_ISLAND = "CTCGACTAGTATGAAGTCCACGCTTG"    # Model (-)

# Test Sequence
S_TEST = "CAGGTTGGAAACGTAA"

# Nucleotides
NUCLEOTIDES = ['A', 'C', 'G', 'T']

# ==========================================
# 2. HELPER FUNCTIONS
# ==========================================

def count_transitions(sequence):
    """
    Counts the dinucleotide transitions in a sequence.
    Returns a dictionary of dictionaries: counts[from_base][to_base]
    """
    # Initialize 4x4 matrix with zeros
    counts = {b1: {b2: 0 for b2 in NUCLEOTIDES} for b1 in NUCLEOTIDES}
    
    # Iterate through sequence and count pairs
    for i in range(len(sequence) - 1):
        curr_n = sequence[i]
        next_n = sequence[i+1]
        counts[curr_n][next_n] += 1
        
    return counts

def calculate_frequencies(counts):
    """
    Converts raw counts to transition probabilities (frequencies).
    P(Next|Curr) = Count(Curr->Next) / Total(Curr)
    """
    freqs = {b1: {b2: 0.0 for b2 in NUCLEOTIDES} for b1 in NUCLEOTIDES}
    
    for b1 in NUCLEOTIDES:
        total_transitions = sum(counts[b1].values())
        if total_transitions > 0:
            for b2 in NUCLEOTIDES:
                freqs[b1][b2] = counts[b1][b2] / total_transitions
        else:
            # If a base never appears as a start point, probabilities remain 0
            # (Though in these specific strings, all bases appear)
            pass
            
    return freqs

def calculate_llm(model_plus, model_minus):
    """
    Creates the Log-Likelihood Matrix.
    Formula: log2( P_plus / P_minus )
    
    Handles 0 probabilities using a small epsilon to avoid math errors,
    mimicking the behavior seen in the provided PDF tables (e.g., -56.85).
    """
    llm = {b1: {b2: 0.0 for b2 in NUCLEOTIDES} for b1 in NUCLEOTIDES}
    epsilon = 1e-17 # Small number to replace 0 for log calculations
    
    for b1 in NUCLEOTIDES:
        for b2 in NUCLEOTIDES:
            p_plus = model_plus[b1][b2]
            p_minus = model_minus[b1][b2]
            
            # Logic to handle zeros based on provided lab tables:
            
            # Case 1: Both are zero. No information. Log-odds = 0.
            if p_plus == 0 and p_minus == 0:
                llm[b1][b2] = 0.00
                
            # Case 2: Only P_plus is zero. Very unlikely in Island model.
            # log2(epsilon / p_minus) -> Large Negative number
            elif p_plus == 0:
                llm[b1][b2] = math.log2(epsilon / p_minus)
                
            # Case 3: Only P_minus is zero. Very likely in Island model.
            # log2(p_plus / epsilon) -> Large Positive number
            elif p_minus == 0:
                llm[b1][b2] = math.log2(p_plus / epsilon)
                
            # Case 4: Normal calculation
            else:
                # Using math.log2 directly (equivalent to ln(x)/ln(2))
                llm[b1][b2] = math.log2(p_plus / p_minus)
                
    return llm

def print_matrix(matrix, title):
    """Pretty prints a 4x4 matrix"""
    print(f"\n--- {title} ---")
    header = "\t" + "\t".join(NUCLEOTIDES)
    print(header)
    for b1 in NUCLEOTIDES:
        row_str = f"{b1}\t"
        for b2 in NUCLEOTIDES:
            val = matrix[b1][b2]
            # Format to 3 decimal places for readability
            row_str += f"{val:.3f}\t"
        print(row_str)

# ==========================================
# 3. MAIN EXECUTION
# ==========================================

# --- Step 1 & 2: Count and Frequency ---

# Model (+) for CpG Island
counts_plus = count_transitions(S1_ISLAND)
freqs_plus = calculate_frequencies(counts_plus)
print_matrix(freqs_plus, "Step 1: CpG+ Model Frequencies (S1)")

# Model (-) for Non-Island
counts_minus = count_transitions(S2_NON_ISLAND)
freqs_minus = calculate_frequencies(counts_minus)
print_matrix(freqs_minus, "Step 2: CpG- Model Frequencies (S2)")

# --- Step 3: Log Likelihood Matrix ---

llm = calculate_llm(freqs_plus, freqs_minus)
print_matrix(llm, "Step 3: Log-Likelihood Matrix (LLM)")

# --- Step 4: Test New Sequence ---

score = 0
print(f"\n--- Testing Sequence S: {S_TEST} ---")
print("Transitions and scores:")

for i in range(len(S_TEST) - 1):
    curr_n = S_TEST[i]
    next_n = S_TEST[i+1]
    
    val = llm[curr_n][next_n]
    score += val
    
    print(f"  {curr_n} -> {next_n} : {val:.4f}")

print(f"\nTotal Score: {score:.4f}")

# Conclusion
if score > 0:
    print(">>> Conclusion: The sequence IS a CpG island (Score > 0)")
else:
    print(">>> Conclusion: The sequence is NOT a CpG island (Score < 0)")
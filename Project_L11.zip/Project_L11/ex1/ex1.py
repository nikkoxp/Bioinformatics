import math

def main():
    # ---------------------------------------------------------
    # 1. INPUT DATA
    # ---------------------------------------------------------
    # Transcribed from the first image (Rows 1-10)
    motifs = [
        "GAGGTAAAC", # 1
        "TCCGTAAGT", # 2
        "CAGGTTGGA", # 3
        "ACAGTCAGT", # 4
        "TAGGTCATT", # 5
        "TAGGTACTG", # 6
        "ATGGTAACT", # 7
        "CAGGTATAC", # 8
        "TGTGTGAGT", # 9
        "AAGGTAAGT"  # 10
    ]

    target_sequence_S = "CAGGTTGGAAACGTAATCAGCGATTACGCATGACGTAA"
    
    motif_length = len(motifs[0])
    num_sequences = len(motifs)
    bases = ['A', 'C', 'G', 'T']
    
    # Background probability (Null Model)
    # As per the second image: P(A)=P(T)=P(C)=P(G) = 0.25
    null_model = 0.25

    print(f"--- Configuration ---")
    print(f"Number of motifs: {num_sequences}")
    print(f"Motif length: {motif_length}")
    print(f"Null Model Prob: {null_model}")
    print("-" * 60)

    # ---------------------------------------------------------
    # STEP 1: Make the Count Matrix
    # ---------------------------------------------------------
    # Initialize 4x9 matrix with zeros
    count_matrix = {b: [0]*motif_length for b in bases}

    for seq in motifs:
        for i, char in enumerate(seq):
            count_matrix[char][i] += 1

    print("\n1. Count Matrix (PFM):")
    print_matrix(count_matrix, motif_length, bases, decimal_places=0)

    # ---------------------------------------------------------
    # STEP 2 & 3: Make the Relative Frequencies (Probability) Matrix
    # ---------------------------------------------------------
    # Frequency = Count / Total Sequences
    freq_matrix = {b: [0.0]*motif_length for b in bases}
    
    for b in bases:
        for i in range(motif_length):
            freq_matrix[b][i] = count_matrix[b][i] / num_sequences

    print("\n3. Relative Frequencies Matrix (PPM):")
    print_matrix(freq_matrix, motif_length, bases, decimal_places=2)

    # ---------------------------------------------------------
    # STEP 4: Make the Log-likelihoods Matrix
    # ---------------------------------------------------------
    # Score = ln( Observed_Freq / Null_Model )
    # Note: If frequency is 0, the log is undefined (-infinity).
    # We will use a large negative number to represent -inf for scoring.
    
    log_likelihood_matrix = {b: [0.0]*motif_length for b in bases}
    NEG_INF_REPLACEMENT = -99.0 # Arbitrary large negative score for impossible matches

    for b in bases:
        for i in range(motif_length):
            obs_freq = freq_matrix[b][i]
            if obs_freq > 0:
                # Using natural log (ln) as indicated in the image
                score = math.log(obs_freq / null_model)
            else:
                score = NEG_INF_REPLACEMENT
            log_likelihood_matrix[b][i] = score

    print("\n4. Log-likelihoods Matrix (Weight Matrix/PWM):")
    print_matrix(log_likelihood_matrix, motif_length, bases, decimal_places=2)

    # ---------------------------------------------------------
    # STEP 5: Analyze Sequence S (Sliding Window)
    # ---------------------------------------------------------
    print("\n5. Sliding Window Analysis of Sequence S:")
    print(f"Sequence S: {target_sequence_S}")
    print("-" * 60)
    print(f"{'Index':<6} | {'Window Seq':<12} | {'Score':<10}")
    print("-" * 60)

    best_score = -9999
    best_index = -1
    best_subseq = ""

    # Slide window
    # Range goes up to len(S) - motif_length
    for i in range(len(target_sequence_S) - motif_length + 1):
        window = target_sequence_S[i : i + motif_length]
        
        current_score = 0.0
        possible_match = True
        
        for pos, char in enumerate(window):
            val = log_likelihood_matrix[char][pos]
            if val == NEG_INF_REPLACEMENT:
                possible_match = False
            current_score += val
        
        # Formatting score for display
        if current_score < -50:
            score_display = "-Inf" # Display as -Inf if it hits the impossible constraint
        else:
            score_display = f"{current_score:.4f}"

        print(f"{i:<6} | {window:<12} | {score_display}")

        # Track best score (ignoring impossible matches)
        if possible_match and current_score > best_score:
            best_score = current_score
            best_index = i
            best_subseq = window

    print("-" * 60)
    print("RESULTS INTERPRETATION:")
    if best_score > 0:
        print(f"Strongest Signal found at Index {best_index}: {best_subseq}")
        print(f"Max Score: {best_score:.4f}")
        print("YES, there are signals indicating an exon-intron border.")
        print("Note: The positions with 'G' at index 3 and 'T' at index 4 (0-based) are critical.")
    else:
        print("No strong positive signal found.")

def print_matrix(matrix, length, bases, decimal_places=2):
    # Print Header
    header = "   | " + "  ".join([f"{i+1:<4}" for i in range(length)])
    print(header)
    print("---|" + "-" * (length * 6))
    
    # Print Rows
    for b in bases:
        row_str = f" {b} | "
        for i in range(length):
            val = matrix[b][i]
            if decimal_places == 0:
                row_str += f"{int(val):<4}  "
            else:
                row_str += f"{val:<5.{decimal_places}f} "
        print(row_str)

if __name__ == "__main__":
    main()
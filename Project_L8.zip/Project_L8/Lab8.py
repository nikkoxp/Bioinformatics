import os

def read_dna_file(filename):
    try:
        with open(filename, 'r') as f:
            content = f.read()
            
            if content.startswith(">"):
                content = "\n".join(content.split("\n")[1:])
            
            sequence = content.replace('\n', '').replace('\r', '').replace(' ', '').upper()
            return sequence
    except FileNotFoundError:
        print(f"Error: The file '{filename}' was not found.")
        print("Please ensure the file exists or create it for testing.")
        return None

def find_cuts_and_fragments(dna, enzyme_name, recognition_seq, cut_offset):
    cut_positions = []
    search_start = 0
    
    while True:
        index = dna.find(recognition_seq, search_start)
        if index == -1:
            break
        cut_site = index + cut_offset
        cut_positions.append(cut_site)
        search_start = index + 1

    boundaries = [0] + cut_positions + [len(dna)]
    fragments = []
    
    for i in range(len(boundaries) - 1):
        length = boundaries[i+1] - boundaries[i]
        fragments.append(length)

    fragments.sort(reverse=True)
    
    return {
        "name": enzyme_name,
        "cut_count": len(cut_positions),
        "cut_positions": cut_positions,
        "fragments": fragments
    }

def print_gel_simulation(results):
    print("\n" + "="*60)
    print("3. ELECTROPHORESIS GEL SIMULATION (ASCII)")
    print("="*60)
    print("Top (Large Fragments) -> Bottom (Small Fragments)\n")
    
    header = f"{'Approx bp':<10} |"
    for res in results:
        header += f" {res['name']:<7} |"
    print(header)
    print("-" * len(header))

    for size in range(3000, 0, -100):
        row_str = f"{size:<10} |"
        has_band = False
        
        for res in results:
            symbol = "       "
            for frag in res['fragments']:
                if size - 50 <= frag < size + 50:
                    symbol = "  ---  "
                    has_band = True
            row_str += f" {symbol:<7} |"
        
        if has_band:
            print(row_str)
    
    print("-" * len(header))

def main():
    filename = "full_dna_sequence.fna"
    
    if not os.path.exists(filename):
        print(f"(!) '{filename}' not found. Creating a random dummy file for testing...")
        import random
        bases = "ACGT"
        dummy_seq = "".join(random.choice(bases) for _ in range(2148))
        with open(filename, "w") as f:
            f.write(dummy_seq)

    dna_sequence = read_dna_file(filename)
    
    if not dna_sequence:
        return

    print(f"Analyzing DNA Sequence (Length: {len(dna_sequence)} bp)\n")

    enzymes = [
        ("EcoRI",   "GAATTC", 1),
        ("BamHI",   "GGATCC", 1),
        ("HindIII", "AAGCTT", 1),
        ("TaqI",    "TCGA",   1),
        ("HaeIII",  "GGCC",   2)
    ]

    results = []

    for name, pattern, offset in enzymes:
        res = find_cuts_and_fragments(dna_sequence, name, pattern, offset)
        results.append(res)

    print("="*60)
    print("1. & 2. CLEAVAGE COUNTS, POSITIONS & FRAGMENT SIZES")
    print("="*60)
    
    for res in results:
        print(f"[{res['name']}]")
        print(f"  > Recognition Pattern: {next(x[1] for x in enzymes if x[0] == res['name'])}")
        print(f"  > Number of cuts: {res['cut_count']}")
        print(f"  > Cut positions (indices): {res['cut_positions']}")
        print(f"  > Fragment lengths (bp): {res['fragments']}")
        print("-" * 30)

    print_gel_simulation(results)

if __name__ == "__main__":
    main()
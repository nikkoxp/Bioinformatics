import matplotlib.pyplot as plt

def read_fasta(filename: str) -> str:
    sequence = ""
    try:
        with open(filename, 'r') as f:
            for line in f:
                if not line.startswith('>'):
                    sequence += line.strip()
    except FileNotFoundError:
        print(f"Couldn't find this file: '{filename}'.")
        return ""
    return sequence.upper()

def calculate_melting_temp(dna_fragment: str) -> float:
    count_g = dna_fragment.count('G')
    count_c = dna_fragment.count('C')
    count_a = dna_fragment.count('A')
    count_t = dna_fragment.count('T')
    
    melting_temp = (4 * (count_g + count_c)) + (2 * (count_a + count_t))
    return float(melting_temp)

def main():
    fasta_file = 'sequence.fasta'
    window_size = 9
    step = 1

    dna_sequence = read_fasta(fasta_file)
    if not dna_sequence:
        print(f"Couldn't read the sequence from {fasta_file}.")
        return

    vector_P = []
    positions = []

    for i in range(0, len(dna_sequence) - window_size + 1, step):
        window = dna_sequence[i:i + window_size]
        tm = calculate_melting_temp(window)
        vector_P.append(tm)
        positions.append(i + window_size // 2)

    try:
        threshold1 = float(input("Enter the threshold value (27 is a good value): "))
    except ValueError:
        print("Invalid input.")
        return

    plt.figure(figsize=(12, 6))
    
    plt.plot(positions, vector_P, label=f'Tm Profile (Window Size={window_size})', color='blue')
    
    plt.axhline(y=threshold1, color='red', linestyle='--', label=f'Threshold 1 = {threshold1}°C')
    
    plt.title('Melting Temperature of DNA Sequence')
    plt.xlabel('Position in Sequence (bp)')
    plt.ylabel('Melting Temperature (Tm) °C')
    plt.grid(True)
    plt.legend()
    
    x_limits = plt.xlim()
    
    plt.show()

    regions = []
    in_region = False
    start_pos = 0

    for i, tm in enumerate(vector_P):
        pos = positions[i]
        if tm > threshold1 and not in_region:
            in_region = True
            start_pos = pos
        elif tm <= threshold1 and in_region:
            in_region = False
            regions.append((start_pos, positions[i-1]))
    if in_region:
        regions.append((start_pos, positions[-1]))

    if not regions:
        print("No regions found above the specified threshold.")
        return

    plt.figure(figsize=(12, 3))
    
    for i, (start, end) in enumerate(regions):
        if i == 0:
            plt.hlines(y=1, xmin=start, xmax=end, color='red', linewidth=10, label=f'Regions Above {threshold1}°C')
        else:
            plt.hlines(y=1, xmin=start, xmax=end, color='red', linewidth=10)
            
    plt.title('Positions Where Melting Temperature Exceeds Threshold')
    plt.xlabel('Position in Sequence (bp)')
    
    plt.xlim(x_limits)
    
    plt.ylim(0.5, 1.5)
    plt.yticks([])
    plt.grid(axis='x', linestyle='--')
    plt.legend()
    plt.show()

if __name__ == "__main__":
    main()
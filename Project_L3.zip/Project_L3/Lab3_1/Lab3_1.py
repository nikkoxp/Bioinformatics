import math

def calculate_melting_temperatures(dna_sequence: str) -> tuple:
    dna_sequence = dna_sequence.upper()
    length = len(dna_sequence)

    if length == 0:
        print("Error: The DNA sequence cannot be empty.")
        return 0.0, 0.0

    valid_chars = set("ATCG")
    if not set(dna_sequence).issubset(valid_chars):
        print("Error: The DNA sequence contains invalid characters.")
        return 0.0, 0.0

    count_a = dna_sequence.count('A')
    count_t = dna_sequence.count('T')
    count_c = dna_sequence.count('C')
    count_g = dna_sequence.count('G')

    tm_basic = (4 * (count_g + count_c)) + (2 * (count_a + count_t))

    gc_percent = ((count_g + count_c) * 100 / length) 
    
    tm_salt_adjusted = abs(81.5 + (16.6 * math.log10(0.001)) + 0.41 * (gc_percent) - (600 / length))

    return float(tm_basic), tm_salt_adjusted

if __name__ == "__main__":
    input_sequence = input("Enter the DNA sequence: ")

    if not input_sequence:
        print("Error: No DNA sequence entered.")
    else:
        tm1, tm2 = calculate_melting_temperatures(input_sequence)
        
        if tm1 > 0.0 and tm2 > 0.0:
            print(f"The sequence entered is: {input_sequence.upper()}")
            print(f"Melting Temperature (Basic Formula): {tm1} degrees Celsius")
            print(f"Melting Temperature (Fancy Formula): {tm2:.5f} degrees Celsius")
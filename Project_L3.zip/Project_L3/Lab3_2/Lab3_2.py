import matplotlib.pyplot as plt

def read_fasta(filename: str) -> str:

    sequence = ""
    with open(filename, 'r') as f:
        for line in f:
                sequence += line.strip()
    return sequence.upper()

def calculate_melting_temp(dna_fragment: str) -> float:

    count_g = dna_fragment.count('G')
    count_c = dna_fragment.count('C')
    count_a = dna_fragment.count('A')
    count_t = dna_fragment.count('T')
    
    melting_temp = (4 * (count_g + count_c)) + (2 * (count_a + count_t))
    return float(melting_temp)

def main():

    fasta_file = 'sequence.fasta'
    window_size = 9
    step = 1

    dna_sequence = read_fasta(fasta_file)
    if not dna_sequence:
        print(f"I couldn't read your FASTA file: {fasta_file}.")
        return

    vector_P = []
    positions = []


    for i in range(0, len(dna_sequence) - window_size + 1, step):
        window = dna_sequence[i:i + window_size]
        
        tm = calculate_melting_temp(window)
        vector_P.append(tm)
        
        positions.append(i + window_size // 2)

    plt.figure(figsize=(12, 6))
    plt.plot(positions, vector_P, label=f'Tm (Window Size={window_size})')
    
    plt.title('Melting Temperature of DNA Sequence')
    plt.xlabel('Position in Sequence (bp)')
    plt.ylabel('Melting Temperature (Tm) °C')
    plt.grid(True)
    plt.legend()
    plt.show()

if __name__ == "__main__":
    main()
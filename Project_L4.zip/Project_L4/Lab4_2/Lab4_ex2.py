import re
import sys
from collections import Counter

# --- Helper Functions ---

def get_codon_table():
    """
    Returns the genetic code as a Python dictionary.
    Keys are 3-letter RNA codons. Values are 3-letter amino acid codes.
    """
    return {
        'UUU': 'Phe', 'UUC': 'Phe', 'UUA': 'Leu', 'UUG': 'Leu',
        'UCU': 'Ser', 'UCC': 'Ser', 'UCA': 'Ser', 'UCG': 'Ser',
        'UAU': 'Tyr', 'UAC': 'Tyr', 'UAA': 'Stop', 'UAG': 'Stop',
        'UGU': 'Cys', 'UGC': 'Cys', 'UGA': 'Stop', 'UGG': 'Trp',
        'CUU': 'Leu', 'CUC': 'Leu', 'CUA': 'Leu', 'CUG': 'Leu',
        'CCU': 'Pro', 'CCC': 'Pro', 'CCA': 'Pro', 'CCG': 'Pro',
        'CAU': 'His', 'CAC': 'His', 'CAA': 'Gln', 'CAG': 'Gln',
        'CGU': 'Arg', 'CGC': 'Arg', 'CGA': 'Arg', 'CGG': 'Arg',
        'AUU': 'Ile', 'AUC': 'Ile', 'AUA': 'Ile', 'AUG': 'Met',
        'ACU': 'Thr', 'ACC': 'Thr', 'ACA': 'Thr', 'ACG': 'Thr',
        'AAU': 'Asn', 'AAC': 'Asn', 'AAA': 'Lys', 'AAG': 'Lys',
        'AGU': 'Ser', 'AGC': 'Ser', 'AGA': 'Arg', 'AGG': 'Arg',
        'GUU': 'Val', 'GUC': 'Val', 'GUA': 'Val', 'GUG': 'Val',
        'GCU': 'Ala', 'GCC': 'Ala', 'GCA': 'Ala', 'GCG': 'Ala',
        'GAU': 'Asp', 'GAC': 'Asp', 'GAA': 'Glu', 'GAG': 'Glu',
        'GGU': 'Gly', 'GGC': 'Gly', 'GGA': 'Gly', 'GGG': 'Gly',
    }

def read_fasta_file(filename):
    """
    Reads a FASTA file and returns its content as a string.
    Includes error handling for FileNotFoundError.
    """
    try:
        with open(filename, 'r') as file:
            return file.read()
    except FileNotFoundError:
        print(f"Error: The file '{filename}' was not found.")
        print("Please make sure the file is in the same directory as the script.")
        sys.exit(1) # Exit the script with an error code
    except Exception as e:
        print(f"An error occurred while reading '{filename}': {e}")
        sys.exit(1)

def parse_fasta(file_content):
    """
    Parses a FASTA file's content, removes headers and newlines,
    and returns a single, contiguous DNA sequence.
    """
    # Find all lines that do not start with '>'
    sequence_lines = re.findall(r"^(?!>)(.*)", file_content, re.MULTILINE)
    # Join them and remove any lingering whitespace/newlines
    dna_sequence = "".join(sequence_lines).replace('\n', '').replace('\r', '')
    return dna_sequence.upper()

def count_codons(dna_sequence):
    """
    Counts all valid codons in a DNA sequence.
    Transcribes T -> U for RNA codon analysis.
    Skips codons with invalid characters (like 'N' or 'R').
    """
    codon_counts = Counter()
    valid_bases = {'A', 'C', 'G', 'T'} # Valid DNA bases

    for i in range(0, len(dna_sequence) - 2, 3):
        codon = dna_sequence[i:i+3]
        
        # Ensure all bases in the codon are standard DNA bases
        if all(base in valid_bases for base in codon):
            # Transcribe to RNA (T -> U) to match the codon table
            rna_codon = codon.replace('T', 'U')
            codon_counts[rna_codon] += 1
            
    return codon_counts

# --- Main Analysis ---

if __name__ == "__main__":
    
    # 1. Load and parse genomes by reading files
    print("Reading FASTA files...")
    influenza_fna_content = read_fasta_file("Influenza.fna")
    covid_fna_content = read_fasta_file("Covid.fna")

    # Note: Influenza file contains multiple segments; they are combined.
    covid_dna = parse_fasta(covid_fna_content)
    influenza_dna = parse_fasta(influenza_fna_content)
    print("Files processed.")

    # 2. Count codons
    covid_codon_counts = count_codons(covid_dna)
    influenza_codon_counts = count_codons(influenza_dna)

    # 3. Get Top 10 for (a) and (b)
    top_10_covid = covid_codon_counts.most_common(10)
    top_10_influenza = influenza_codon_counts.most_common(10)

    print("\n--- Analysis of COVID-19 and Influenza A Genomes ---")

    # a. Top 10 Influenza Codons
    print("\n## a. Top 10 Codons (Influenza A)")
    print("---------------------------------")
    print(f"{'Rank':<5} {'Codon':<8} {'Count':<8}")
    print("-" * 27)
    for i, (codon, count) in enumerate(top_10_influenza, 1):
        print(f"{i:<5} {codon:<8} {count:<8}")

    # b. Top 10 COVID Codons
    print("\n## b. Top 10 Codons (COVID-19)")
    print("------------------------------")
    print(f"{'Rank':<5} {'Codon':<8} {'Count':<8}")
    print("-" * 27)
    for i, (codon, count) in enumerate(top_10_covid, 1):
        print(f"{i:<5} {codon:<8} {count:<8}")

    # c. Compare Results
    print("\n## c. Shared Codons in Top 10 Lists")
    print("---------------------------------")
    set_covid_codons = {c[0] for c in top_10_covid}
    set_influenza_codons = {c[0] for c in top_10_influenza}
    
    shared_codons = set_covid_codons.intersection(set_influenza_codons)
    
    if shared_codons:
        print("The following codons appear in the top 10 for BOTH genomes:")
        print(", ".join(sorted(list(shared_codons))))
    else:
        print("There are no shared codons in the top 10 lists.")

    # d. Top 3 Amino Acids
    print("\n## d. Top 3 Amino Acids (from top codons)")
    print("------------------------------------------")
    codon_table = get_codon_table()
    
    print("\nCOVID-19 (Wuhan-Hu-1):")
    for codon, count in top_10_covid[:3]:
        amino_acid = codon_table.get(codon, "Unknown")
        print(f"  - {codon} (Count: {count}) translates to: {amino_acid}")

    print("\nInfluenza A (A/California/07/2009(H1N1)):")
    for codon, count in top_10_influenza[:3]:
        amino_acid = codon_table.get(codon, "Unknown")
        print(f"  - {codon} (Count: {count}) translates to: {amino_acid}")
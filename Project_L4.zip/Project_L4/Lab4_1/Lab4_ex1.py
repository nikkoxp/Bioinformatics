import sys

def get_codon_table():

    codon_table = {
        'UUU': 'Phe', 'UUC': 'Phe', 'UUA': 'Leu', 'UUG': 'Leu',
        'UCU': 'Ser', 'UCC': 'Ser', 'UCA': 'Ser', 'UCG': 'Ser',
        'UAU': 'Tyr', 'UAC': 'Tyr', 'UAA': 'Stop', 'UAG': 'Stop',
        'UGU': 'Cys', 'UGC': 'Cys', 'UGA': 'Stop', 'UGG': 'Trp',
        
        'CUU': 'Leu', 'CUC': 'Leu', 'CUA': 'Leu', 'CUG': 'Leu',
        'CCU': 'Pro', 'CCC': 'Pro', 'CCA': 'Pro', 'CCG': 'Pro',
        'CAU': 'His', 'CAC': 'His', 'CAA': 'Gln', 'CAG': 'Gln',
        'CGU': 'Arg', 'CGC': 'Arg', 'CGA': 'Arg', 'CGG': 'Arg',

        'AUU': 'Ile', 'AUC': 'Ile', 'AUA': 'Ile', 'AUG': 'Met',
        'ACU': 'Thr', 'ACC': 'Thr', 'ACA': 'Thr', 'ACG': 'Thr',
        'AAU': 'Asn', 'AAC': 'Asn', 'AAA': 'Lys', 'AAG': 'Lys',
        'AGU': 'Ser', 'AGC': 'Ser', 'AGA': 'Arg', 'AGG': 'Arg',

        'GUU': 'Val', 'GUC': 'Val', 'GUA': 'Val', 'GUG': 'Val',
        'GCU': 'Ala', 'GCC': 'Ala', 'GCA': 'Ala', 'GCG': 'Ala',
        'GAU': 'Asp', 'GAC': 'Asp', 'GAA': 'Glu', 'GAG': 'Glu',
        'GGU': 'Gly', 'GGC': 'Gly', 'GGA': 'Gly', 'GGG': 'Gly',
    }
    return codon_table

def translate_rna(rna_sequence):

    table = get_codon_table()
    amino_acids = []
    
    for i in range(0, len(rna_sequence), 3):
        codon = rna_sequence[i:i+3]
        
        if len(codon) < 3:
            break
            
        amino_acid = table.get(codon.upper())
        
        if amino_acid is None:
            print(f"Warning: Invalid codon '{codon}' skipped.", file=sys.stderr)
            continue
            
        if amino_acid == 'Stop':
            break
            
        amino_acids.append(amino_acid)
        
    return "-".join(amino_acids)


if __name__ == "__main__":

    rna_seq_1 = "AUGUUCAACGGGUAGCCC"
    # Translation:
    # AUG -> Met
    # UUC -> Phe
    # AAC -> Asn
    # GGG -> Gly
    # UAG -> Stop
    
    print("First example:")
    print(f"RNA Sequence: {rna_seq_1}")
    protein_1 = translate_rna(rna_seq_1)
    print(f"Amino Acid Seq: {protein_1}")
    print("")

    rna_seq_2 = "AUGCCCAGAUGA"
    # Translation:
    # AUG -> Met
    # CCC -> Pro
    # AGA -> Arg
    # UGA -> Stop
    
    print("Second Example")
    print(f"RNA Sequence: {rna_seq_2}")
    protein_2 = translate_rna(rna_seq_2)
    print(f"Amino Acid Seq: {protein_2}")
    print("")
    print("")
    
    try:
        user_rna = input("Enter your RNA coding sequence: ")
        user_protein = translate_rna(user_rna)
        if user_protein:
            print(f"Translated Protein: {user_protein}")
        else:
            print("No protein was translated (sequence might be too short or start with a stop codon).")
    except EOFError:
        print("\nExiting.")
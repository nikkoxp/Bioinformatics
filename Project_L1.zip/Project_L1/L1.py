import matplotlib.pyplot as plt

sequence = "ACGTGGATGGTTTAGAGGAATCACATTCAAGTCTGGTTAACCATGAAACAAGTCTTGAGTGTAAAATTGTCGTCTCCTGTGTACGAGATGGAGGTACTAGATGACTGCAGGGACTCCGACGTTATGTACGTTGCTCCGTCAAAGGCGCCATTCAGGATCACGTTACCGCCAAAAAATGGGAGCAGGAGCTCTTCTCCCCT"

sequence = sequence.upper()
length = len(sequence)

counts = {base: sequence.count(base) for base in "ATGC"}

percentages = {base: (count / length) * 100 for base, count in counts.items()}

cg_count = sequence.count("CG")

#total posible dinucleotides = length - 1 (since pairs overlap)
total_dinucs = length - 1
cg_percentage = (cg_count / total_dinucs) * 100

print("=== Nucleotide Composition ===")
for base in "ATGC":
    print(f"{base}: {percentages[base]:.2f}%")

print(f"\nCG dinucleotide percentage: {cg_percentage:.2f}%")


plt.figure(figsize=(5, 4))
plt.bar(["CG"], [cg_percentage], color="teal")
plt.ylabel("Percentage (%)")
plt.title("CG Dinucleotide Content")
plt.ylim(0, 100)
plt.tight_layout()
plt.show()

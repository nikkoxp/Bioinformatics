Team of 3:
Radu Matei
Munteanu Amalia-Nicole
Francu Teodor-Matei
import zipfile
import os
import glob
import matplotlib.pyplot as plt
import numpy as np
import shutil

# --- Configuration ---
WINDOW_SIZE = 200  # Window size for sliding analysis
INFLUENZA_ZIP = 'Influenza.zip'
SARS_ZIP = 'Sars.zip'
TEMP_DIR = 'temp_genome_data'

def ensure_clean_dir(directory):
    if os.path.exists(directory):
        shutil.rmtree(directory)
    os.makedirs(directory)

def extract_zip(zip_path, extract_to):
    """Extracts a zip file to the specified directory."""
    if not os.path.exists(zip_path):
        print(f"Warning: {zip_path} not found. Skipping.")
        return False
    
    try:
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_to)
        return True
    except zipfile.BadZipFile:
        print(f"Error: {zip_path} is not a valid zip file.")
        return False

def parse_fasta_genome(file_path):
    """
    Parses a FASTA file. 
    - For Influenza (multi-segment), it concatenates all segments.
    - For Covid (single), it reads the sequence.
    Returns the header (name) and the concatenated sequence.
    """
    sequence = []
    header = None
    
    with open(file_path, 'r') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith('>'):
                if header is None:
                    header = line[1:] # Keep the first header as ID
            else:
                sequence.append(line)
    
    full_sequence = "".join(sequence)
    # Basic cleaning
    full_sequence = full_sequence.upper().replace('N', '') 
    return header, full_sequence

def calculate_cg_content(sequence):
    length = len(sequence)
    if length == 0: return 0
    c_count = sequence.count('C')
    g_count = sequence.count('G')
    return ((c_count + g_count) / length) * 100

def calculate_kappa_ic(sequence):
    length = len(sequence)
    if length == 0: return 0
    bases = ['A', 'C', 'G', 'T']
    sum_probs_squared = 0
    for base in bases:
        prob = sequence.count(base) / length
        sum_probs_squared += prob ** 2
    return sum_probs_squared * 100

def get_sliding_window_data(sequence, win_size):
    cg_values = []
    ic_values = []
    
    # Using a step size to speed up processing for large genomes if needed.
    # Here we use step=1 for precision.
    for i in range(len(sequence) - win_size + 1):
        window = sequence[i : i + win_size]
        cg_values.append(calculate_cg_content(window))
        ic_values.append(calculate_kappa_ic(window))
        
    return cg_values, ic_values

def calculate_center_of_weight(values):
    """Calculates the center of weight index."""
    total_mass = sum(values)
    if total_mass == 0:
        return 0
    weighted_indices = sum(i * val for i, val in enumerate(values))
    return weighted_indices / total_mass

def process_genomes_in_folder(folder_path, label_prefix):
    """Finds fasta files, processes them, and returns analysis data."""
    # Find all .fna or .fasta files recursively
    files = glob.glob(os.path.join(folder_path, '**', '*.fna'), recursive=True)
    files += glob.glob(os.path.join(folder_path, '**', '*.fasta'), recursive=True)
    
    results = []
    
    print(f"Found {len(files)} files in {folder_path}...")
    
    for file_path in files:
        filename = os.path.basename(file_path)
        header, sequence = parse_fasta_genome(file_path)
        
        if len(sequence) < WINDOW_SIZE:
            continue

        print(f"Processing {label_prefix}: {filename} ({len(sequence)} bp)")
        
        cg_trace, ic_trace = get_sliding_window_data(sequence, WINDOW_SIZE)
        
        cow_cg_idx = calculate_center_of_weight(cg_trace)
        cow_ic_idx = calculate_center_of_weight(ic_trace)
        
        # Normalize CoW (0.0 to 1.0) for fair comparison between different genome lengths
        norm_cow_cg = cow_cg_idx / len(cg_trace)
        norm_cow_ic = cow_ic_idx / len(ic_trace)
        
        results.append({
            'name': filename,
            'header': header,
            'type': label_prefix,
            'cg_trace': cg_trace,
            'ic_trace': ic_trace,
            'cow_cg': cow_cg_idx,
            'cow_ic': cow_ic_idx,
            'norm_cow_cg': norm_cow_cg,
            'norm_cow_ic': norm_cow_ic,
            'length': len(sequence)
        })
        
    return results

def main():
    # 1. Prepare environment
    ensure_clean_dir(TEMP_DIR)
    
    # 2. Extract Zips
    flu_dir = os.path.join(TEMP_DIR, 'Influenza')
    sars_dir = os.path.join(TEMP_DIR, 'Sars')
    
    flu_extracted = extract_zip(INFLUENZA_ZIP, flu_dir)
    sars_extracted = extract_zip(SARS_ZIP, sars_dir)
    
    if not flu_extracted and not sars_extracted:
        print("No zip files extracted. Please ensure Influenza.zip and Sars.zip are uploaded.")
        return

    # 3. Process Data
    flu_data = process_genomes_in_folder(flu_dir, 'Influenza')
    sars_data = process_genomes_in_folder(sars_dir, 'Covid-19')
    
    all_data = flu_data + sars_data
    
    if not all_data:
        print("No valid genome data found.")
        return

    # 4. Plotting
    
    # --- Chart 1: Objective Digital Stains (Kappa IC Patterns) ---
    fig1, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10))
    
    # Plot Influenza Traces
    for genome in flu_data:
        ax1.plot(genome['ic_trace'], linewidth=1, alpha=0.6)
    ax1.set_title(f'Objective Digital Stains: Influenza (Window: {WINDOW_SIZE}bp)')
    ax1.set_ylabel('Kappa IC')
    ax1.set_xlabel('Position (bp)')
    ax1.grid(True, alpha=0.3)
    
    # Plot Covid Traces
    for genome in sars_data:
        ax2.plot(genome['ic_trace'], linewidth=1, alpha=0.6)
    ax2.set_title(f'Objective Digital Stains: Covid-19 (Window: {WINDOW_SIZE}bp)')
    ax2.set_ylabel('Kappa IC')
    ax2.set_xlabel('Position (bp)')
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    # --- Chart 2: Centers of Weight (Scatter Plot) ---
    # We plot Normalized CoW of CG vs Normalized CoW of IC to separate the clusters
    fig2, ax3 = plt.subplots(figsize=(10, 8))
    
    # Plot Influenza Points
    if flu_data:
        flu_x = [d['norm_cow_cg'] for d in flu_data]
        flu_y = [d['norm_cow_ic'] for d in flu_data]
        ax3.scatter(flu_x, flu_y, color='blue', s=100, label='Influenza', alpha=0.7, edgecolors='black')
        
        # Label points
        for i, d in enumerate(flu_data):
            ax3.annotate(f"Flu-{i+1}", (d['norm_cow_cg'], d['norm_cow_ic']), fontsize=8, alpha=0.7)

    # Plot Covid Points
    if sars_data:
        cov_x = [d['norm_cow_cg'] for d in sars_data]
        cov_y = [d['norm_cow_ic'] for d in sars_data]
        ax3.scatter(cov_x, cov_y, color='red', s=100, label='Covid-19', alpha=0.7, edgecolors='black')
        
        # Label points
        for i, d in enumerate(sars_data):
            ax3.annotate(f"Cov-{i+1}", (d['norm_cow_cg'], d['norm_cow_ic']), fontsize=8, alpha=0.7)

    ax3.set_title('Center of Weight Map (Normalized)')
    ax3.set_xlabel('Center of Weight (C+G%) - Normalized Position (0-1)')
    ax3.set_ylabel('Center of Weight (Kappa IC) - Normalized Position (0-1)')
    ax3.legend()
    ax3.grid(True, linestyle='--', alpha=0.5)
    
    # Add mean centroids for the groups
    if flu_data:
        mean_flu_x = np.mean([d['norm_cow_cg'] for d in flu_data])
        mean_flu_y = np.mean([d['norm_cow_ic'] for d in flu_data])
        ax3.scatter([mean_flu_x], [mean_flu_y], color='blue', marker='X', s=200, label='Flu Mean')
        
    if sars_data:
        mean_cov_x = np.mean([d['norm_cow_cg'] for d in sars_data])
        mean_cov_y = np.mean([d['norm_cow_ic'] for d in sars_data])
        ax3.scatter([mean_cov_x], [mean_cov_y], color='red', marker='X', s=200, label='Cov Mean')

    plt.tight_layout()
    plt.show()

    # Cleanup
    try:
        shutil.rmtree(TEMP_DIR)
    except:
        pass

if __name__ == "__main__":
    main()
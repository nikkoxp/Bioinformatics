import matplotlib.pyplot as plt
import numpy as np

def calculate_cg_content(sequence):
    """
    Calculates the C+G percentage of a DNA sequence.
    Formula: (Count(C) + Count(G)) / Length * 100
    """
    if not sequence:
        return 0.0
    
    sequence = sequence.upper()
    c_count = sequence.count('C')
    g_count = sequence.count('G')
    return ((c_count + g_count) / len(sequence)) * 100

def calculate_kappa_ic(sequence):
    """
    Calculates the Index of Coincidence (Kappa IC) for a DNA sequence.
    Formula: Sum(Pi^2) * 100
    Where Pi is the probability (frequency) of each base (A, C, G, T).
    Random DNA has an IC of 25.0. 
    """
    if not sequence:
        return 0.0
    
    sequence = sequence.upper()
    length = len(sequence)
    bases = ['A', 'C', 'G', 'T']
    
    sum_probs_squared = 0
    for base in bases:
        count = sequence.count(base)
        prob = count / length
        sum_probs_squared += prob ** 2
        
    return sum_probs_squared * 100

def calculate_center_of_weight(values):
    """
    Calculates the Center of Weight (Centroid) of a 1D array of values.
    Formula: Sum(Index * Value) / Sum(Value)
    """
    total_mass = sum(values)
    if total_mass == 0:
        return 0
    
    weighted_indices = sum(i * val for i, val in enumerate(values))
    return weighted_indices / total_mass

def main():

    S = "CGGACTGATCTATCTAAAAAAAAAAAAAAAAAAAAAAAAAAACGTAGCATCTATCGATCTATCTAGCGATCTATCTACTACG"
    
    print(f"Analyzing Sequence: {S}")
    global_cg = calculate_cg_content(S)
    global_ic = calculate_kappa_ic(S)

    print("-" * 30)
    print("GLOBAL SEQUENCE ANALYSIS (Verification)")
    print("-" * 30)
    print(f"Target CG: 29.27 | Calculated CG: {global_cg:.2f}")
    print(f"Target IC: 27.53 | Calculated IC: {global_ic:.2f}")
    
    if abs(global_cg - 29.27) < 0.1 and abs(global_ic - 27.53) < 0.1:
        print(">> VERIFICATION SUCCESSFUL: Values match target criteria.")
    else:
        print(">> NOTE: Values differ slightly. Ensure target values refer to the full sequence.")


    window_size = 30
    cg_pattern = []
    ic_pattern = []
    
    for i in range(len(S) - window_size + 1):
        window = S[i : i + window_size]
        cg_pattern.append(calculate_cg_content(window))
        ic_pattern.append(calculate_kappa_ic(window))

    # 6. Calculate Center of Weight for the patterns
    cg_cow_index = calculate_center_of_weight(cg_pattern)
    ic_cow_index = calculate_center_of_weight(ic_pattern)
    
    print("\n" + "-" * 30)
    print("PATTERN CENTERS OF WEIGHT")
    print("-" * 30)
    print(f"CG Pattern Center (Index): {cg_cow_index:.2f}")
    print(f"IC Pattern Center (Index): {ic_cow_index:.2f}")

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 10))
    
    x_axis = range(len(cg_pattern))
    ax1.plot(x_axis, cg_pattern, label='C+G %', color='blue', linewidth=2)
    ax1.plot(x_axis, ic_pattern, label='Kappa IC', color='red', linewidth=2, linestyle='--')
    ax1.set_title(f'DNA Pattern Analysis (Window Size: {window_size})')
    ax1.set_xlabel('Window Start Position')
    ax1.set_ylabel('Value')
    ax1.legend()
    ax1.grid(True, alpha=0.3)

    ax2.set_title('Center of Weight (Centroids) of Patterns')
    

    ax2.plot([0, len(cg_pattern)], [1, 1], color='blue', alpha=0.3, label='CG Range')
    ax2.plot([0, len(ic_pattern)], [2, 2], color='red', alpha=0.3, label='IC Range')
 
    ax2.scatter([cg_cow_index], [1], color='blue', s=200, zorder=5, label='CG Center')
    ax2.scatter([ic_cow_index], [2], color='red', s=200, zorder=5, label='IC Center')
    
    ax2.text(cg_cow_index, 1.1, f'  CG Center: {cg_cow_index:.1f}', color='blue', fontweight='bold')
    ax2.text(ic_cow_index, 2.1, f'  IC Center: {ic_cow_index:.1f}', color='red', fontweight='bold')

    ax2.set_xlim(0, len(cg_pattern))
    ax2.set_ylim(0, 3)
    ax2.set_yticks([])
    ax2.set_xlabel('Window Index')
    ax2.legend()
    ax2.grid(True, axis='x', alpha=0.3)

    plt.tight_layout()
    
    print("\n>> Instructions for Step 8:")
    print("   Open PromKappa with a promoter sequence.")
    print("   Compare the visual shape of the generated graphs above with the PromKappa output.")
    
    plt.show()

if __name__ == "__main__":
    main()
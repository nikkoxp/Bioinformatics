import random
import math
import os

DNA_FILE = "full_dna_sequence.fna"

NUM_SAMPLES = 10

MIN_FRAGMENT_LEN = 100

GEL_HEIGHT = 30 

def run_simulation():
    print(f"Attempting to read DNA sequence from '{DNA_FILE}'...")
    
    if not os.path.exists(DNA_FILE):
        print(f"Error: File not found: '{DNA_FILE}'")
        print("Please make sure the file is in the same directory as this script.")
        return

    try:
        with open(DNA_FILE, 'r') as f:
            full_sequence = f.read().strip().upper()
        if not full_sequence:
            print("Error: The file is empty.")
            return
        max_length = len(full_sequence)
        print(f"Successfully read sequence. Total length: {max_length} bp\n")
    except Exception as e:
        print(f"An error occurred while reading the file: {e}")
        return
    
    print(f"Generating {NUM_SAMPLES} random fragment lengths...")
    
    dna_fragments = []
    for _ in range(NUM_SAMPLES):
        length = random.randint(MIN_FRAGMENT_LEN, max_length)
        dna_fragments.append(length)

    print(f"Generated fragments (bp): {dna_fragments}\n")
    print("Simulating Gel Electrophoresis...")
    print("Note: Shorter fragments travel farther (move to the bottom).")
    
    
    dna_fragments.sort() 
    
    relative_distances = {}
    for length in dna_fragments:
        relative_distances[length] = 1 / math.log10(length)
    
    min_relative_dist = relative_distances[dna_fragments[-1]]
    max_relative_dist = relative_distances[dna_fragments[0]]
    dist_range = max_relative_dist - min_relative_dist

    gel_visualization = ["|              |" for _ in range(GEL_HEIGHT)]
    
    gel_visualization[0] = "|--- WELL ---|"
    
    band_positions = set()

    for length in reversed(dna_fragments):
        dist = relative_distances[length]
        if dist_range > 0:
            norm_dist = (dist - min_relative_dist) / dist_range
        else:
            norm_dist = 0.5 
        pos = 1 + int(norm_dist * (GEL_HEIGHT - 3))
        while pos in band_positions and pos < (GEL_HEIGHT - 1):
            pos += 1 
        band_positions.add(pos)
        band_label = f"{length} bp"
        gel_visualization[pos] = f"|-- {band_label:<10} --|" 
    
    print("=" * 18)
    for line in gel_visualization:
        print(line)
    print("=" * 18)
    print("Simulation Complete.")

if __name__ == "__main__":
    run_simulation()
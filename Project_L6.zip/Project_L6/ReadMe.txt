Team of 2:
Radu Matei
Munteanu Amalia-Nicole

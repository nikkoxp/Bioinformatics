#!/usr/bin/env python

"""
Bioinformatics Lab Exercise 2: Restriction Digest Simulator

This script simulates a restriction digest on a DNA sequence using
multiple enzymes and visualizes the resulting fragments on an
electrophoresis gel.

- Reads a DNA sequence from 'full_dna_sequence.fna'
- Defines 5 common restriction enzymes and their cut sites
- Finds all cut sites in the sequence
- Calculates the lengths of the resulting fragments
- Simulates the gel migration for these fragments
"""

import random
import math
import os

# --- Configuration ---

# The file containing your full DNA sequence
DNA_FILE = "full_dna_sequence.fna"

# The "height" of our text-based gel in lines
GEL_HEIGHT = 30 

# Define our 5 restriction enzymes
# Format: { 'Enzyme Name': ('Recognition_Site', Cut_Position_Offset) }
# The offset is the 0-indexed position *after* which the cut is made.
# e.g., G^AATTC means the cut is after 'G' (index 0), so offset is 1.
RESTRICTION_ENZYMES = {
    'EcoRI':   ('GAATTC', 1),  # G^AATTC
    'BamHI':   ('GGATCC', 1),  # G^GATCC
    'HindIII': ('AAGCTT', 1),  # A^AGCTT
    'NotI':    ('GCGGCCGC', 2),  # GC^GGCCGC
    'PstI':    ('CTGCAG', 5)   # CTGCA^G
}

# --- Core Functions ---

def read_sequence(filename):
    """
    Reads a DNA sequence from the specified file.
    Returns the sequence as a string, or None if an error occurs.
    """
    print(f"Attempting to read DNA sequence from '{filename}'...")
    
    if not os.path.exists(filename):
        print(f"Error: File not found: '{filename}'")
        return None

    try:
        with open(filename, 'r') as f:
            full_sequence = f.read().strip().upper()
        
        if not full_sequence:
            print("Error: The file is empty.")
            return None

        print(f"Successfully read sequence. Total length: {len(full_sequence)} bp\n")
        return full_sequence

    except Exception as e:
        print(f"An error occurred while reading the file: {e}")
        return None

def perform_digest(sequence, enzymes):
    """
    Simulates a restriction digest on the sequence with all enzymes.
    Returns a list of fragment lengths.
    """
    print("Performing restriction digest with 5 enzymes...")
    
    total_length = len(sequence)
    
    # Use a set to store cut positions to auto-handle duplicates
    cut_positions = set()

    # Find all cut sites for all enzymes
    for enzyme, (site, cut_offset) in enzymes.items():
        start_index = 0
        while True:
            # Find the next occurrence of the recognition site
            index = sequence.find(site, start_index)
            
            # If no more sites are found, break from this enzyme's loop
            if index == -1:
                break
            
            # Calculate the actual cut position
            cut_pos = index + cut_offset
            cut_positions.add(cut_pos)
            
            # Move start_index to search for the next site
            start_index = index + 1
    
    # --- Calculate fragment lengths ---
    
    # Add the start (0) and end (total_length) to our list
    # of "cuts" to get all fragment lengths correctly.
    all_break_points = sorted(list(cut_positions) + [0, total_length])
    
    fragments = []
    
    # Calculate the lengths between adjacent break points
    for i in range(len(all_break_points) - 1):
        length = all_break_points[i+1] - all_break_points[i]
        if length > 0:
            fragments.append(length)

    print(f"Digest complete. Found {len(fragments)} fragments.")
    if len(fragments) < 20:
        print(f"Fragment lengths (bp): {fragments}\n")
    else:
        print(f"Fragment lengths (bp): [{fragments[0]}, {fragments[1]}, ... , {fragments[-1]}]\n")
        
    return fragments


def visualize_gel(fragment_list, gel_height=GEL_HEIGHT):
    """
    Simulates and prints a text-based gel for a list of fragments.
    Uses the corrected logic from Exercise 1.
    """
    print("Simulating Gel Electrophoresis...")
    print("Note: Shorter fragments travel farther (move to the bottom).")
    
    # Sort fragments by length, shortest to longest
    fragment_list.sort() 
    
    if not fragment_list:
        print("No fragments to visualize.")
        return

    # Calculate relative migration distances (1 / log(length))
    relative_distances = {}
    for length in fragment_list:
        relative_distances[length] = 1 / math.log10(length)

    # Find min/max migration distances
    min_relative_dist = relative_distances[fragment_list[-1]] # Longest frag
    max_relative_dist = relative_distances[fragment_list[0]] # Shortest frag
    dist_range = max_relative_dist - min_relative_dist
    
    # Create an empty gel
    gel_visualization = ["|              |" for _ in range(gel_height)]
    gel_visualization[0] = "|--- WELL ---|"
    band_positions = set()

    # --- Visualization Loop (Corrected) ---
    # Iterate from LONGEST to SHORTEST fragment
    for length in reversed(fragment_list):
        dist = relative_distances[length]
        
        if dist_range > 0:
            norm_dist = (dist - min_relative_dist) / dist_range
        else:
            norm_dist = 0.5
        
        pos = 1 + int(norm_dist * (gel_height - 3))

        # Handle "collisions" (bands that are too close)
        while pos in band_positions and pos < (gel_height - 1):
            pos += 1 # Nudge the band down one line
        
        if pos < (gel_height - 1):
            band_positions.add(pos)
            band_label = f"{length} bp"
            gel_visualization[pos] = f"|-- {band_label:<10} --|"
        
    # Print the final gel
    print("=" * 18)
    for line in gel_visualization:
        print(line)
    print("=" * 18)
    print("Simulation Complete.")


# --- Main script execution ---

if __name__ == "__main__":
    
    # Step 1: Read the sequence
    dna_sequence = read_sequence(DNA_FILE)
    
    if dna_sequence:
        # Step 2: Perform the digest
        fragments = perform_digest(dna_sequence, RESTRICTION_ENZYMES)
        
        if fragments:
            # Step 3: Visualize the results
            visualize_gel(fragments)
        else:
            print("No fragments were generated. This likely means")
            print("none of the enzyme recognition sites were found.")
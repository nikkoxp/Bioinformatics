import sys
import os

def read_fasta(filename):
    if not os.path.exists(filename):
        print(f"Warning: File {filename} not found.")
        return ""
        
    sequence = []
    with open(filename, 'r') as f:
        for line in f:
            if not line.startswith('>'):
                sequence.append(line.strip().upper())
    return "".join(sequence)

def get_reverse_complement(seq):
    complement = {'A': 'T', 'C': 'G', 'G': 'C', 'T': 'A', 'N': 'N'}
    return "".join(complement.get(base, base) for base in reversed(seq))

def find_transposons(sequence, min_ir=4, max_ir=6, min_dist=100, max_dist=2000, check_tsd=True):
    print(f"Scanning {len(sequence)} bp sequence...")
    candidates = {}

    kmer_positions = {}
    
    for k in range(min_ir, max_ir + 1):
        kmer_positions[k] = {}
        for i in range(len(sequence) - k + 1):
            kmer = sequence[i : i+k]
            if kmer not in kmer_positions[k]:
                kmer_positions[k][kmer] = []
            kmer_positions[k][kmer].append(i)

    for k in range(min_ir, max_ir + 1):
        for kmer_seq, left_positions in kmer_positions[k].items():
            
            rc_seq = get_reverse_complement(kmer_seq)
            
            if rc_seq in kmer_positions[k]:
                right_positions = kmer_positions[k][rc_seq]                
                for start in left_positions:
                    for end in right_positions:
                        
                        dist = end - start
                        if min_dist <= dist <= max_dist:
                            
                            valid = True
                            tsd_seq = ""
                            if check_tsd:
                                valid = False
                                max_tsd_len = 5
                                for t_len in range(2, max_tsd_len + 1):
                                    if start - t_len < 0 or end + k + t_len > len(sequence):
                                        continue
                                    
                                    left_flank = sequence[start - t_len : start]
                                    right_flank = sequence[end + k : end + k + t_len]
                                    
                                    if left_flank == right_flank:
                                        valid = True
                                        tsd_seq = left_flank
                                        break
                            
                            if valid:
                                te_key = (start, end + k)
                                
                                if te_key in candidates:
                                    if k > candidates[te_key]['ir_len']:
                                        candidates[te_key]['ir_len'] = k
                                        candidates[te_key]['ir_seq'] = kmer_seq
                                else:
                                    candidates[te_key] = {
                                        'start': start,
                                        'end': end + k,
                                        'length': (end + k) - start,
                                        'ir_seq': kmer_seq,
                                        'ir_len': k,
                                        'tsd': tsd_seq if check_tsd else "N/A",
                                        'status': "Independent"
                                    }

    return list(candidates.values())

def analyze_relationships(te_list):
    te_list.sort(key=lambda x: x['start'])
    
    for i in range(len(te_list)):
        current = te_list[i]
        
        for j in range(len(te_list)):
            if i == j: continue
            other = te_list[j]
            
            if other['start'] < current['start'] and other['end'] > current['end']:
                current['status'] = f"Involved (Nested in TE at {other['start']})"
            
            elif (other['start'] < current['start'] < other['end']) and (current['end'] > other['end']):
                current['status'] = f"Overlapping (with TE at {other['start']})"

def main():
    print("--- BIOINFORMATICS EXERCISE 2: TRANSPOSON DETECTION ---\n")
    
    genome_files = ["genome1.fna", "genome2.fna", "genome3.fna"]
    
    for fname in genome_files:
        print(f"Processing file: {fname}")
        seq = read_fasta(fname)
        
        if not seq:
            print("   [Skipping: Empty or missing file]")
            print("-" * 50)
            continue
            
        tes = find_transposons(seq, min_ir=4, max_ir=6, check_tsd=True)
        
        analyze_relationships(tes)
        
        print(f"   Found {len(tes)} candidates.")
        print(f"   {'Start':<10} | {'End':<10} | {'Length':<8} | {'IR (Len)':<15} | {'Status'}")
        print("   " + "-"*80)
        
        display_limit = 50
        for te in tes[:display_limit]:
            ir_info = f"{te['ir_seq']} ({te['ir_len']})"
            print(f"   {te['start']:<10} | {te['end']:<10} | {te['length']:<8} | {ir_info:<15} | {te['status']}")
        
        if len(tes) > display_limit:
            print(f"   ... and {len(tes) - display_limit} more.")
            
        print("-" * 50 + "\n")

if __name__ == "__main__":
    main()
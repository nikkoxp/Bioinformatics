import random

def generate_random_dna(length):
    return ''.join(random.choice('ACGT') for _ in range(length))

def insert_transposon(host_dna, transposon_seq, start_index, tsd_length):
    target_site = host_dna[start_index : start_index + tsd_length]
    
    left_part = host_dna[:start_index + tsd_length]
    right_part = host_dna[start_index:]
    
    new_sequence = left_part + transposon_seq + right_part

    return new_sequence, target_site

def main():
    print("--- BIOINFORMATICS TRANSPOSON SIMULATION ---\n")
    initial_length = random.randint(200, 400)
    dna_seq = generate_random_dna(initial_length)
    
    print(f"1. Generated Host DNA (Length {len(dna_seq)} bp)")
    print(f"   Preview: {dna_seq[:10]}...{dna_seq[-10:]}\n")

    transposons = [
        {"name": "Tn1", "seq": "gatc_TRANSPOSON_ONE_gatc"},
        {"name": "Tn2", "seq": "ctag_TRANSPOSON_TWO_ctag"},
        {"name": "Tn3", "seq": "ttaa_TRANSPOSON_THREE_ttaa"}
    ]

    tsd_len = 5 

    last_insertion_index = 0
    last_transposon_len = 0

    for i, tn in enumerate(transposons):
        current_len = len(dna_seq)
        
        if i == 1: 
            start_range = last_insertion_index + tsd_len + 2
            end_range = last_insertion_index + last_transposon_len
            insert_idx = random.randint(start_range, end_range)
            print(f"   [!] FORCING INTERSECTION: Inserting {tn['name']} inside Tn1...")
        else:
            insert_idx = random.randint(0, current_len - tsd_len - 1)

        new_dna, created_tsd = insert_transposon(dna_seq, tn['seq'], insert_idx, tsd_len)
        
        print(f"--- Event {i+1}: Inserting {tn['name']} ---")
        print(f"   Location: Index {insert_idx}")
        print(f"   Target Site Duplicated (TSD): {created_tsd}")
        
        start_view = max(0, insert_idx)
        end_view = min(len(new_dna), insert_idx + len(tn['seq']) + (tsd_len*2))
        snippet = new_dna[start_view : end_view]
        
        print(f"   Structure created: ...{created_tsd}-{tn['seq']}-{created_tsd}...")
        
        dna_seq = new_dna
        
        last_insertion_index = insert_idx
        last_transposon_len = len(tn['seq'])

    print("\n--- Final Sequence Details ---")
    print(f"Original Length: {initial_length}")
    print(f"Final Length:    {len(dna_seq)}")
    print("\nFinal Sequence (truncated view):")
    print(dna_seq[:100] + "...(cont)..." + dna_seq[-50:])
    print(dna_seq)

    with open("simulated_output.fna", "w") as f:
        f.write(dna_seq)

if __name__ == "__main__":
    main()
Team of 3:
Francu-Teodor Matei
Munteanu Amalia-Nicole
Radu Matei

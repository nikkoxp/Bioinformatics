
S = "TACGTGCGCGCGAGCTATCTACTGACTTACGACTAGTGTAGCTGCATCATCGATCGA"
ALPHABET = "ACGT"

dinucleotides = [a+b for a in ALPHABET for b in ALPHABET]
trinucleotides = [a+b+c for a in ALPHABET for b in ALPHABET for c in ALPHABET]
print(dinucleotides)
print(trinucleotides)

def count_kmers(seq: str, kmers: list[str], k: int):
    L = len(seq)
    total = max(L-k+1, 0)
    counts = {km: 0 for km in kmers}
    for i in range(total):
        km = seq[i:i+k]
        if km in counts:
            counts[km] = counts[km]+1 #overlapping incrementation, made the most sense to me
    return counts, total

def compute_percentages(counts: dict[str, int], total: int):

    if total == 0:
        return {km: 0.0 for km in counts}
    return {km: (counts[km]/total*100.0) for km in counts}

def print_table(title: str, counts: dict[str, int], total: int, percentages: dict[str, float], top_n: int | None = None):

    print(f"\nCurrent table: {title}")
    print(f"Total overlapping k-mer: {total} (I did it with overlapping increments) \n")
    print(f"{'k-mer':<6} {'Count':>5} {'Total':>7} {'Percentage':>12}")
    print("-" * 34)
    for km in sorted(counts):  # alphabetical sorting so that it outputs nicely
        pct = percentages[km]
        print(f"{km:<6} {counts[km]:>5} {total:>7} {pct:>11.2f}%")
    
    if top_n is not None and top_n > 0:
        print("\nTop by percentage:") #sorting by percentage (I like being organized, so it's going to be only the top 10 sequences)
        ranked = sorted(counts.keys(), key=lambda x: percentages[x], reverse=True)
        for km in ranked[:top_n]:
            print(f"{km:<6} {counts[km]:>5} {total:>7} {percentages[km]:>11.2f}%")


counts2, total2 = count_kmers(S, dinucleotides, 2)
perc2 = compute_percentages(counts2, total2)

counts3, total3 = count_kmers(S, trinucleotides, 3)
perc3 = compute_percentages(counts3, total3)

print_table("Dinucleotide percentages (k=2)", counts2, total2, perc2, top_n=10)
print_table("Trinucleotide percentages (k=3)", counts3, total3, perc3, top_n=10)


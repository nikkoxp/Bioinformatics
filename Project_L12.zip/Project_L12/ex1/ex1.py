import numpy as np

def run_prediction(matrix_data, initial_vector, steps=5):
    # Convert inputs to numpy arrays for efficient calculation
    M = np.array(matrix_data)
    v = np.array(initial_vector)
    
    # VALIDATION: Check if matrix is square and dimensions match
    rows, cols = M.shape
    vec_len = v.shape[0]
    
    if rows != cols:
        raise ValueError(f"Error: Matrix must be square. Current shape is {rows}x{cols}.")
    if cols != vec_len:
        raise ValueError(f"Error: Matrix columns ({cols}) must match vector length ({vec_len}).")

    print(f"--- Starting Prediction for {steps} Steps ---")
    print(f"Initial State (t=0): {v}")
    print("-" * 40)

    current_v = v
    
    # Loop through the discrete steps
    for t in range(1, steps + 1):
        # Calculate the next step: v(t) = M * v(t-1)
        # np.dot is the standard matrix multiplication in numpy
        next_v = np.dot(M, current_v)
        
        print(f"Step {t}: {next_v}")
        
        # Update current vector for the next iteration
        current_v = next_v

    print("-" * 40)
    print("Prediction Complete.")

if __name__ == "__main__":
    my_matrix = [
        [0.6, 0.5, 0.2],
        [0.3, 0.4, 0.3],
        [0.1, 0.1, 0.5]
    ]

    my_initial_vector = [100, 50, 25]

    try:
        run_prediction(my_matrix, my_initial_vector, steps=5)
    except ValueError as e:
        print(e)
Team of 3:
Munteanu Amalia-Nicole
Radu Matei
Francu Teodor-Matei
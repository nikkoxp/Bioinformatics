import random
from collections import defaultdict, Counter

DNA_FILENAME = "full_dna_sequence.fna"
PREFIX_LENGTH = 2000
MIN_SAMPLE_LEN = 100
MAX_SAMPLE_LEN = 150
SAMPLE_STEP_SIZE = 20
KMER_SIZE = 21

def load_sequence(filename):
    print(f"Loading sequence from FASTA file: {filename}")
    sequence_parts = []
    
    try:
        with open(filename, 'r') as f:
            for line in f:
                if line.startswith(">"):
                    continue 
                else:
                    sequence_parts.append(line.strip())
        
        full_sequence = "".join(sequence_parts)

        if not full_sequence:
            print(f"Error: No sequence data found in '{filename}'.")
            return None
            
        print(f"Successfully loaded sequence with {len(full_sequence)} bases.")
        return full_sequence.upper()
        
    except FileNotFoundError:
        print(f"Error: File not found at '{filename}'")
        print("Please make sure the file is in the same directory as the script.")
        return None

def generate_samples(sequence_prefix):
    print(f"Generating samples from the first {len(sequence_prefix)} bases...")
    
    samples_list = []
    current_position = 0
    prefix_total_length = len(sequence_prefix)
    
    while current_position < prefix_total_length:
        sample_len = random.randint(MIN_SAMPLE_LEN, MAX_SAMPLE_LEN)
        end_position = current_position + sample_len
        
        if end_position > prefix_total_length:
            end_position = prefix_total_length
        
        sample = sequence_prefix[current_position:end_position]
        
        if len(sample) >= MIN_SAMPLE_LEN:
            samples_list.append(sample)
        
        current_position += SAMPLE_STEP_SIZE
        
        if prefix_total_length - current_position < MIN_SAMPLE_LEN:
            last_sample = sequence_prefix[current_position:]
            if len(last_sample) > KMER_SIZE: 
                 samples_list.append(last_sample)
            break
            
    print(f"Generated {len(samples_list)} samples.")
    return samples_list

def build_de_bruijn_graph(samples, k):
    print(f"Building De Bruijn graph with k = {k}...")
    
    graph = defaultdict(Counter) 
    in_degree = defaultdict(int)
    out_degree = defaultdict(int)
    
    for sample in samples:
        for i in range(len(sample) - k + 1):
            kmer = sample[i:i+k]
            prefix = kmer[:-1] 
            suffix = kmer[1:]
            
            graph[prefix][suffix] += 1
            
            out_degree[prefix] += 1
            in_degree[suffix] += 1
            
    return graph, in_degree, out_degree

def find_start_node(graph, in_degree, out_degree):
    for node in out_degree:
        if out_degree[node] > in_degree[node]:
            print(f"Found start node: {node}")
            return node
            
    print("No clear start node found. Picking first node as fallback.")
    return list(graph.keys())[0]

def calculate_accuracy(original, assembled):
    matches = 0
    len_orig = len(original)
    len_assem = len(assembled)
    
    total_len = max(len_orig, len_assem)
    
    if total_len == 0:
        return 100.0

    for i in range(total_len):
        if i < len_orig and i < len_assem:
            if original[i] == assembled[i]:
                matches += 1
    
    accuracy = (matches / total_len) * 100.0
    return accuracy

def assemble_sequence_with_graph(samples):
    graph, in_degree, out_degree = build_de_bruijn_graph(samples, KMER_SIZE)
    
    if not graph:
        print("Error: Graph is empty. Cannot assemble.")
        return ""
        
    start_node = find_start_node(graph, in_degree, out_degree)
    
    print("Assembling sequence from graph...")
    
    assembled_sequence = [start_node]
    current_node = start_node
    
    while current_node in graph:
        possible_next_nodes = graph[current_node]

        if not possible_next_nodes:
            break

        next_node = max(possible_next_nodes, key=possible_next_nodes.get)
        
        assembled_sequence.append(next_node[-1])
        
        possible_next_nodes[next_node] -= 1
        
        if possible_next_nodes[next_node] == 0:
            del possible_next_nodes[next_node]
        
        current_node = next_node
    
    return "".join(assembled_sequence)

def main():
    full_sequence = load_sequence(DNA_FILENAME)
    if full_sequence is None:
        return 
        
    original_prefix_len = min(len(full_sequence), PREFIX_LENGTH)
    original_prefix = full_sequence[0:original_prefix_len]

    samples_list = generate_samples(original_prefix)
    
    random.shuffle(samples_list)
    print("Shuffled samples list.")

    assembled_sequence = assemble_sequence_with_graph(samples_list)
    
    print("\n--- Results ---")
    
    accuracy = calculate_accuracy(original_prefix, assembled_sequence)
    print(f"Assembly Accuracy:         {accuracy:.2f}%")
    print(f"Original prefix length:    {len(original_prefix)}")
    print(f"Assembled sequence length: {len(assembled_sequence)}")
    
    if accuracy == 100.0:
        print("SUCCESS! The assembled sequence perfectly matches the original.")
    else:
        print("FAILED. The assembled sequence does NOT perfectly match the original.")

if __name__ == "__main__":
    main()